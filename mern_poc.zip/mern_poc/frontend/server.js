const express = require ("express");
const cors = require("cors");
const mongoose = require("mongoose");

const app = express();
app.use(express.json());    
app.use(cors());

mongoose.connect("mongodb+srv://haneeftaj:xA3jJfOulu2jPITw@cluster0.1xiu8ij.mongodb.net/"
).then( () => console.log("DB Connected"))
.catch( err => console.log("err"));

app.get("/", (req, res) => {
    res.send("Express server is running");
});

app.listen(3001, function() {
    console.log("express server is running on port 3001");
});