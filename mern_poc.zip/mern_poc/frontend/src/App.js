import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navbarmenu from "./components/Navbarmenu";
import Home from "./components/Home";
import Notes from "./components/Notes";
import CreateNotes from "./components/CreateNotes";

function App() {
  return (
    <Router>
      <Navbarmenu />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/notes" element={<Notes />} />
        <Route path="/createnotes" element={<CreateNotes />} />
      </Routes>
    </Router>
  );
}

export default App;
