import React , {useState} from "react";
import Button from 'react-bootstrap/Button';

function CreateNotes(){
    const[input, setInput] = useState({
        title: '',
        content: ''   
    })

    function handleChange(event){
        const {name,value} = event.target;

        setInput(prevInput => {
            return {
                ...prevInput,
                [name]:value,
            };
        })
    }

    function handleClick(event) {
        //event.preventDefault();
        console.log(input);
    }

    return <div className="container createnotespage">    
         <br /><h1>Create Notes Page</h1> <br />

    <form>
        <div className="form-group">
            <input name="title" value={input.title} placeholder="title" onChange={handleChange} autoComplete="off" className="form-control"></input>
        </div><br />
        <div className="form-group">
            <textarea name="content" value={input.content} placeholder="content" onChange={handleChange} autoComplete="off" className="form-control"></textarea>
        </div>
    </form><br />

    
    <Button variant="primary" onClick={handleClick}>Save</Button>{' '}</div>
}

export default CreateNotes;