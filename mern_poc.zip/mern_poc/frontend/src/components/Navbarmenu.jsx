import React from "react";
//import {Link} from "react-router-dom";
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import "./styles.css"

function Navbarmenu (){
    return <Navbar className="container navmenu" bg="primary" data-bs-theme="dark">
   
   <Nav className="me-auto">
            <Nav.Link href="/">Home</Nav.Link>
            <Nav.Link href="/notes">Notes</Nav.Link>
            <Nav.Link href="/createnotes">Create Note</Nav.Link>
          </Nav>    
      
    </Navbar>
}

export default Navbarmenu;