import React from "react";

function Notes(){
    return <div className="container notespage">
        <h1>Notes Page</h1>
        <ul className="datacontainer">
            <li>
                Sample Data
            </li>
        </ul>
    </div>
}

export default Notes;